# PT Checker Front End

# PT Checker Front End

## Development

### Getting Started

Install dependencies:

```bash
$ npm install
```

Run in dev mode:
```bash
$ npm start
```


### Useful VSCode Plugins

- [Eslint](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
- [Prettier](https://marketplace.visualstudio.com/items?itemName=esbenp.prettier-vscode)
