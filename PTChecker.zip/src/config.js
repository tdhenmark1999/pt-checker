(function (window) {
  window.__env = window.__env || {};
  window.__env.loginUrl = 'http://ho-myaccess.pjlhuillier.sit/MyAccessLogin.aspx';
  window.__env.apiUrl = 'http://pt30api-v1.pjlhuillier.sit/api';
}(this));
