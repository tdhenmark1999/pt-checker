export const environment = {
  production: true,
  loginUrl: 'http://ho-myaccess.pjlhuillier.sit/MyAccessLogin.aspx',
  apiUrl: 'http://pt30api-v1.pjlhuillier.sit/api',
  clientId: 'ptchecker-client',
  secret: 'F$oImUS%hlJcAM2Z'
};
