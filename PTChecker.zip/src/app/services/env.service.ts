import { Injectable } from '@angular/core';

export class EnvService {

  public loginUrl = '';
  public apiUrl = '';
  public clientId = '';
  public secret = '';
  constructor() { }
}
