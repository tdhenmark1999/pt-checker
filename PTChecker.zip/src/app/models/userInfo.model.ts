export interface IUserInfoModel {
  encryptedUserId: string;
  encryptedName: string;
}

export interface IUserInfo {
  userId: string;
  name: string;
}
