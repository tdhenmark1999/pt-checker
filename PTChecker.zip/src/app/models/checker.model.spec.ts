import { Checker } from './checker.model';

describe('Checker', () => {
  it('should create an instance', () => {
    expect(new Checker()).toBeTruthy();
  });
});
